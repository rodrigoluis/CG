export default class camera {
  constructor() {
    return true
  }
}
