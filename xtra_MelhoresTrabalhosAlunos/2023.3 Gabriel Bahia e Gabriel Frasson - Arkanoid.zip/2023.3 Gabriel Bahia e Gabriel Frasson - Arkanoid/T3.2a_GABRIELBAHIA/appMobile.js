import { GameMobile } from "./GameMobile.js";

new GameMobile();
