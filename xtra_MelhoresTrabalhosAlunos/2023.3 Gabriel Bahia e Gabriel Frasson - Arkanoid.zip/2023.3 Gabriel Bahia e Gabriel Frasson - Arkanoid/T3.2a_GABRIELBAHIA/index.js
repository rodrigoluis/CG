import { GameWeb } from "./GameWeb.js";

new GameWeb();
