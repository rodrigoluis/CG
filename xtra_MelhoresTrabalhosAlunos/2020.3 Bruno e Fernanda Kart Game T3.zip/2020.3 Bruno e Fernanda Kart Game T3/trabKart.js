/*  -- MELHOR TRABALHO DO PERÍODO
Kart Game - 2020.3
BRUNO BERBERT DE CARVALHO
FERNANDA GONCALVES DA SILVA
*/

function main() {

  var stats = initStats();          // To show FPS information
  var scene = new THREE.Scene();    // Create main scene
  var renderer = initRenderer();    // View function in util/utils
  var camera = initCamera(new THREE.Vector3(0, -25, 5)); // Init camera in this position
  var clock = new THREE.Clock();
  var delta = 0; //calculate time passed

  var textureRepeat = 11.35;

  // ----------------- Skybox --------------------------

  camera.far = 6000;
  
  var materialArray = [];
  var texture_ft = new THREE.TextureLoader().load('./assets/skybox/front.png');
  var texture_bk = new THREE.TextureLoader().load('./assets/skybox/back.png');
  var texture_up = new THREE.TextureLoader().load('./assets/skybox/up.png');
  var texture_dn = new THREE.TextureLoader().load('./assets/skybox/down.png');
  var texture_rt = new THREE.TextureLoader().load('./assets/skybox/right.png');
  var texture_lf = new THREE.TextureLoader().load('./assets/skybox/left.png');

  materialArray.push(new THREE.MeshBasicMaterial({ map: texture_ft }));
  materialArray.push(new THREE.MeshBasicMaterial({ map: texture_bk }));
  materialArray.push(new THREE.MeshBasicMaterial({ map: texture_up }));
  materialArray.push(new THREE.MeshBasicMaterial({ map: texture_dn }));
  materialArray.push(new THREE.MeshBasicMaterial({ map: texture_rt }));
  materialArray.push(new THREE.MeshBasicMaterial({ map: texture_lf }));

  for (var i = 0; i < 6; i++)
    materialArray[i].side = THREE.BackSide;

  var skyboxGeo = new THREE.BoxGeometry(5000, 5000, 5000);
  var skybox = new THREE.Mesh(skyboxGeo, materialArray);
  skybox.rotateX(degreesToRadians(90));
  skybox.rotateY(degreesToRadians(110));
  scene.add(skybox);

  // =====================================================


  // --------------- INITIAL LIGHT SETTINGS -------------------

  var lightPositionInit = new THREE.Vector3(0, 100, 500);
  var light = initDefaultLighting(scene, lightPositionInit); // Use default light
  light.visible = true;
  var lightColor = "rgb(255,255,255)";
  var lightIntensity = 0.35;
  var planeMode = false;
  ///---------------------------------------------



  // --------------- INITIAL SETTINGS AND VARIABLES -------------------
  var kartSpeed = 0.0; // kart speed
  var maxSpeed = 2.0;
  var freeCameraMode = false; // camera mode
  var cockPitMode = false; // cockPit camera mode
  var turnAngle = 0; // angle that kart wheels turns
  var angleMov = degreesToRadians(1.3); // angle that kart turns
  var rotAxis = new THREE.Vector3(0, 0, 1); // Set Z axis of the kart

  var zoomFactorY = -3.0, zoomFactorZ = -0.3;

  //renderer.setClearColor(0xb3f0ff); // Background color

  // ---------- ENF OF INITIAL SETTINGS AND VARIABLES -----------------



  // ====================== MOUNTAIN AND STATUE VARIABLES ====================

  // Mountain materials definitions
  var mountainMaterial = new THREE.MeshLambertMaterial({ color: "rgb(100,70,20)" });
  var mountainTipMaterial = new THREE.MeshLambertMaterial({ color: "rgb(170,170,170)" });

  // Mountain 1 Group
  var mtn1_group = new THREE.Group();

  // Mountain 2 Group
  var mtn2_group = new THREE.Group();

  // Statue Group
  var statue_group = new THREE.Group();


  // ----- Mountain 1 Parts ------
  var mtn1_0_obj, mtn1_1_obj, mtn1_2_obj, mtn1_3_obj, mtn1_4_obj, mtn1_5_obj = null;


  // ----- Mountain 2 Parts ------
  var mtn2_0_obj, mtn2_1_obj, mtn2_2_obj, mtn2_3_obj = null;

  // Used for Mountain
  var scale = 0.1;

  // ====================== END MOUNTAIN AND STATUE VARIABLES ====================



  // =================== CREATING AND AJUSTING MOUNTAIN AND STATUE ====================

  // Create Mountains and ajust positions
  createMountain1();
  createMountain2();

  mtn1_group.position.set(10, -30, 0);
  mtn1_group.rotateX(degreesToRadians(90));
  mtn1_group.rotateY(degreesToRadians(180));
  mtn1_group.scale.set(4, 4, 4);

  mtn2_group.position.set(200, 50, -0.5);
  mtn2_group.rotateX(degreesToRadians(90));
  mtn2_group.rotateY(degreesToRadians(110));
  mtn2_group.scale.set(3, 3, 3);

  // Load Traffic Light
  var traffic_light = new THREE.Group();
  loadGLTFFile('./assets/obj/', 'traffic_light', 15.0, 270, true, traffic_light);
  traffic_light.position.set(40, -23.0, 0);
  scene.add(traffic_light);

  // Load Cactus
  var cactus_group = new THREE.Group();
  loadGLTFFile('./assets/obj/', 'cactus', 25.0, 270, true, cactus_group);
  cactus_group.position.set(44, 110.0, 0);
  scene.add(cactus_group);

  // Load tree
  var tree_group = new THREE.Group();
  loadGLTFFile('./assets/obj/', 'tree', 40.0, 0, true, tree_group);
  tree_group.position.set(-60, 170.0, 0);
  scene.add(tree_group);

  // =================== END OF MOUNTAIN AND STATUE CREATION =================



  // Show text information onscreen
  showInformation();

  // To use the keyboard
  var keyboard = new KeyboardState();

  // Enable mouse rotation, pan, zoom etc.
  var trackballControls = new THREE.TrackballControls(camera, renderer.domElement);
  trackballControls.zoomSpeed = 0.5;


  //--------------- LIGHTING--------------------------

  var spotLight1 = new THREE.SpotLight(lightColor);
  var spotLight2 = new THREE.SpotLight(lightColor);
  var spotLight3 = new THREE.SpotLight(lightColor);
  var spotLight4 = new THREE.SpotLight(lightColor);
  var spotLight5 = new THREE.SpotLight(lightColor);
  var spotLight6 = new THREE.SpotLight(lightColor);
  var spotLight7 = new THREE.SpotLight(lightColor);
  var spotLight8 = new THREE.SpotLight(lightColor);

  var lightPosition1 = new THREE.Vector3(40.0, -155.0, 5.0);
  var lightPosition2 = new THREE.Vector3(115.0, -155.0, 5.0);
  var lightPosition3 = new THREE.Vector3(20.0, 70.0, 5.0);
  var lightPosition4 = new THREE.Vector3(180.0, 150.0, 5.0);
  var lightPosition5 = new THREE.Vector3(-40.0, -155.0, 5.0);
  var lightPosition6 = new THREE.Vector3(-115.0, -155.0, 5.0);
  var lightPosition7 = new THREE.Vector3(-180.0, 150.0, 5.0);
  var lightPosition8 = new THREE.Vector3(-105.0, -20.0, 5.0);

  var pole1 = setSpotLightPole(lightPosition1, spotLight1);
  var pole2 = setSpotLightPole(lightPosition2, spotLight2);
  var pole3 = setSpotLightPole(lightPosition3, spotLight3);
  var pole4 = setSpotLightPole(lightPosition4, spotLight4);
  var pole5 = setSpotLightPole(lightPosition5, spotLight5);
  var pole6 = setSpotLightPole(lightPosition6, spotLight6);
  var pole7 = setSpotLightPole(lightPosition7, spotLight7);
  var pole8 = setSpotLightPole(lightPosition8, spotLight8);

  var dirLight = new THREE.DirectionalLight(lightColor);
  setDirectionalLighting(lightPositionInit);

  var spotLight = new THREE.SpotLight(lightColor);
  setSpotLight(lightPositionInit);

  function setSpotLight(position) {
    spotLight.position.copy(position);
    spotLight.name = "Spot Light"
    spotLight.visible = false;
    spotLight.receiveShadow = true;
    spotLight.castShadow = true;

    camera.add(spotLight);
  }

  function setSpotLightPole(position, spotLightActual) {
    spotLightActual.position.copy(position);

    spotLightActual.distance = 100;
    spotLightActual.receiveShadow = true;
    spotLightActual.castShadow = true;
    spotLightActual.decay = 0.3;
    spotLightActual.penumbra = 0.4;
    spotLightActual.intensity = 3;
    if (position == lightPosition3) {
      spotLightActual.target.position.set(position.x + 30, position.y, position.z);
    }
    spotLightActual.angle = degreesToRadians(45);
    // Shadow Parameters
    spotLightActual.shadow.mapSize.width = 512;
    spotLightActual.shadow.mapSize.height = 512;
    spotLightActual.shadow.camera.fov = radiansToDegrees(spotLightActual.angle);
    spotLightActual.shadow.camera.near = .6;
    spotLightActual.shadow.camera.far = 200.0;

    var pole = createLightPole(position);
    scene.add(spotLightActual);
    spotLightActual.target.updateMatrixWorld();
    return pole;
  }

  function createLightPole(position) {
    var poleGeometry = new THREE.CylinderGeometry(0.5, 0.5, 10.0, 20.0, 4, false);
    var poleMaterial = new THREE.MeshPhongMaterial({ color: "rgb(105,105,105)" });
    var pole = new THREE.Mesh(poleGeometry, poleMaterial);
    pole.castShadow = true;
    pole.receiveShadow = true;
    pole.position.copy(position);
    pole.visible = true;
    pole.rotateX(degreesToRadians(90))

    scene.add(pole);

    var createdSphere = createSphere();
    pole.add(createdSphere);

    return pole;
  }

  function createSphere() {
    var sphereGeometry = new THREE.SphereGeometry(1.5, 20, 20, 0, Math.PI * 2, 0, Math.PI);
    var sphereMaterial = new THREE.MeshPhongMaterial({ color: "rgb(255,250,250)" });
    var sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
    sphere.castShadow = true;
    sphere.position.set(0.0, 5, 0.0);
    sphere.visible = true;

    return sphere;
  }

  function setDirectionalLighting(position) {
    dirLight.position.copy(position);
    dirLight.name = "Direction Light";
    dirLight.visible = true;
    dirLight.receiveShadow = true;
    dirLight.castShadow = true;

    scene.add(dirLight);
  }

  function updateLightIntensity() {
    dirLight.intensity = lightIntensity;
    spotLight.intensity = lightIntensity;
    light.intensity = lightIntensity;
  }

  //----------------------------END LIGHTING---------------------------------

  // --------------- CREATE GROUND PLANE ---------------
  //----------------------------------------------------

  var pistaTexture = new THREE.TextureLoader().load('./assets/ground/pista.jpg');

  var sandTexture = new THREE.TextureLoader().load('./assets/ground/sand.jpg');

  // create the ground plane with wireframe
  var planeGeometry = new THREE.PlaneGeometry(400, 400);
  var planeMaterial = new THREE.MeshPhongMaterial({
    side: THREE.DoubleSide,
    shininess: 5,
  });
  var plane = new THREE.Mesh(planeGeometry, planeMaterial);
  plane.receiveShadow = true;
  scene.add(plane);



  var auxPlaneGeo = new THREE.PlaneGeometry(1600, 1600);
  var auxPlaneMat = new THREE.MeshPhongMaterial({
    side: THREE.DoubleSide,
    shininess: 5,
  });
  var auxPlane = new THREE.Mesh(auxPlaneGeo, auxPlaneMat);
  auxPlane.translateZ(-0.1);
  auxPlane.receiveShadow = true;
  plane.add(auxPlane);

  plane.material.map = pistaTexture;

  auxPlane.material.map = sandTexture;
  auxPlane.material.map.repeat.set(textureRepeat, textureRepeat);
  auxPlane.material.map.wrapS = THREE.RepeatWrapping;
  auxPlane.material.map.wrapT = THREE.RepeatWrapping;


  // --------------- END OF GROUND PLANE ---------------



  // --------------- CREATE KART "SOUL" ---------------
  // Invisible Object that works as a core of the kart (controlling its movement)
  var cubeGeometry = new THREE.Geometry();
  var cubeMaterial = new THREE.MeshStandardMaterial();
  var kartSoul = new THREE.Mesh(cubeGeometry, cubeMaterial);
  // position the kart soul
  kartSoul.position.set(-100.0, -130.0, 0.5);
  kartSoul.rotateZ(degreesToRadians(270));
  // add the kart soul to the scene
  scene.add(kartSoul);
  // attach the camera to the kart soul
  kartSoul.castShadow = true;
  kartSoul.receiveShadow = true;
  kartSoul.add(camera);

  // --------------- END OF KART "SOUL" ---------------



  // =============== CREATING KART MODEL ===============


  // --------------- CREATE KART CHASSIS ---------------
  var chassisGeometry = new THREE.BoxGeometry(1.5, 6, 0.2);

  var redMaterial = new THREE.MeshPhongMaterial({ color: "rgb(180,50,50)" });
  var darkMaterial = new THREE.MeshPhongMaterial({ color: "rgb(20,20,20)" });
  var greyMaterial = new THREE.MeshPhongMaterial({ color: "rgb(80, 80, 80)" });

  var chassis = new THREE.Mesh(chassisGeometry, redMaterial);
  chassis.position.set(0.0, 0.0, 0.0);
  chassis.castShadow = true;
  chassis.receiveShadow = true;
  // attach the chassis to kartSoul
  kartSoul.add(chassis);
  // all kart components will now be attached to chassis


  // --------------- CREATE KART SEAT -------------------

  var seatBackGeo = new THREE.BoxGeometry(1.4, 1.6, 0.2);

  var seatBack = new THREE.Mesh(seatBackGeo, darkMaterial);

  seatBack.castShadow = true; // enable shadow
  seatBack.receiveShadow = true;
  seatBack.position.set(0.0, -1.9, 0.9);
  seatBack.rotateX(1.9);
  chassis.add(seatBack);

  var sbStickerTex = new THREE.TextureLoader().load('./assets/kartTextures/teslaLogo.png');
  var sbGeo = new THREE.PlaneGeometry(0.4, 0.4);
  var sbMat = new THREE.MeshPhongMaterial({ shininess: 50, color: "rgb(180,50,50)" });
  var sbSticker = new THREE.Mesh(sbGeo, sbMat);
  sbSticker.position.set(0, 0.6, 0.12);
  sbSticker.material.map = sbStickerTex;
  sbSticker.material.transparent = true;
  seatBack.add(sbSticker);

  var seatBottom = new THREE.Mesh(seatBackGeo, darkMaterial);
  seatBottom.receiveShadow = true;
  seatBottom.castShadow = true; // enable shadow
  seatBottom.position.set(0.0, -0.9, 0.25);
  chassis.add(seatBottom);


  // --------------- CREATE KART FRAME -------------------

  const sideFrameGeo = new THREE.CylinderGeometry(0.11, 0.11, 2.5, 32);
  const baseFrame = new THREE.CylinderGeometry(0.09, 0.09, 2.4, 32);
  var ironMat = new THREE.MeshPhongMaterial({ color: "rgb(100, 100, 100)" });

  const firstBase = new THREE.Mesh(baseFrame, ironMat);
  firstBase.position.set(0, 1, 0);
  firstBase.rotateZ(1.5708);
  firstBase.receiveShadow = true;
  firstBase.shadow = true;
  chassis.add(firstBase)

  const secondBase = new THREE.Mesh(baseFrame, ironMat);
  secondBase.position.set(0, -1, 0);
  secondBase.rotateZ(1.5708);
  secondBase.castShadow = true;
  secondBase.receiveShadow = true;
  chassis.add(secondBase);

  const leftDown = new THREE.Mesh(sideFrameGeo, ironMat);
  leftDown.position.set(1.2, 0.0, 0);
  leftDown.castShadow = true;
  leftDown.receiveShadow = true;
  chassis.add(leftDown);

  const rightDown = new THREE.Mesh(sideFrameGeo, ironMat);
  rightDown.position.set(-1.2, 0.0, 0);
  rightDown.receiveShadow = true;
  rightDown.castShadow = true;
  chassis.add(rightDown);

  var frameTex = new THREE.TextureLoader().load('./assets/kartTextures/iron.jpg');

  firstBase.material.map = frameTex;



  // ----------------------- CREATE KART AEROFOIL -------------------------


  var aerofoilGeo = new THREE.BoxGeometry(2.6, 1, 0.1);
  var aerofoil = new THREE.Mesh(aerofoilGeo, redMaterial);
  aerofoil.position.set(0.0, -2.7, 0.852);
  aerofoil.rotateX(-0.15);
  aerofoil.castShadow = true;
  aerofoil.receiveShadow = true;
  chassis.add(aerofoil);

  var aerofoilSticker = new THREE.TextureLoader().load('./assets/kartTextures/marlboro2.png');
  var aeroStickerGeo = new THREE.PlaneGeometry(2.6, 1);
  var aeroStickerMat = new THREE.MeshPhongMaterial({ shininess: 50 });
  var afsticker = new THREE.Mesh(aeroStickerGeo, aeroStickerMat);
  afsticker.position.set(0, 0, 0.06);
  afsticker.rotateZ(degreesToRadians(180));
  afsticker.material.map = aerofoilSticker;
  aerofoil.add(afsticker);

  var aerofoilSupGeo = new THREE.BoxGeometry(0.1, 0.6, 0.78);

  var aerofoilLeftSup = new THREE.Mesh(aerofoilSupGeo, redMaterial);
  aerofoilLeftSup.position.set(-0.5, -2.7, 0.47);
  aerofoilLeftSup.castShadow = true;
  aerofoilLeftSup.receiveShadow = true;
  chassis.add(aerofoilLeftSup);

  var aerofoilRightSup = new THREE.Mesh(aerofoilSupGeo, redMaterial);
  aerofoilRightSup.position.set(0.5, -2.7, 0.47);
  aerofoilRightSup.castShadow = true;
  aerofoilRightSup.receiveShadow = true;
  chassis.add(aerofoilRightSup);


  var motorGeo = new THREE.BoxGeometry(0.4, 0.5, 0.6);
  var motorMat = new THREE.MeshPhongMaterial({ color: "rgb(80, 80, 80)" });
  var motor = new THREE.Mesh(motorGeo, motorMat);
  motor.position.set(0.2, -2.7, 0.4);
  motor.castShadow = true;
  //motor.receiveShadow = true;
  chassis.add(motor);

  var motor2Geo = new THREE.BoxGeometry(0.3, 0.5, 0.5);
  var motor2 = new THREE.Mesh(motor2Geo, motorMat);

  motor2.position.set(-0.1, -2.5, 0.2);
  motor2.castShadow = true;
  //motor2.receiveShadow = true;
  chassis.add(motor2);

  var motorTex = new THREE.TextureLoader().load('./assets/kartTextures/engine.jpg');

  motor.material.map = motorTex;


  // ----------------------- CREATE KART FRONT WING -------------------------

  var frontAngWingGeo = new THREE.BoxGeometry(2.6, 0.7, 0.1);

  var frontAngWing = new THREE.Mesh(frontAngWingGeo, darkMaterial);
  frontAngWing.position.set(0.0, 3.1, 0.11);
  frontAngWing.rotateX(-0.4);
  frontAngWing.castShadow = true;
  frontAngWing.receiveShadow = true;
  chassis.add(frontAngWing);

  var fwingSticker = new THREE.TextureLoader().load('./assets/kartTextures/tesla2.png');
  var fwStickerGeo = new THREE.PlaneGeometry(2.4, 0.3);
  var fwStickerMat = new THREE.MeshPhongMaterial({ shininess: 50 });
  var fwSticker = new THREE.Mesh(fwStickerGeo, fwStickerMat);
  fwSticker.position.set(0, 0, 0.06);
  fwSticker.rotateZ(degreesToRadians(180));
  fwSticker.material.map = fwingSticker;
  fwSticker.material.transparent = true;
  frontAngWing.add(fwSticker);

  var frontSidesGeo = new THREE.BoxGeometry(0.05, 0.7, 0.4);

  var leftWing = new THREE.Mesh(frontSidesGeo, redMaterial);
  leftWing.position.set(-1.31, 3.1, 0.1);
  leftWing.castShadow = true;
  leftWing.receiveShadow = true;
  chassis.add(leftWing);

  var rightWing = new THREE.Mesh(frontSidesGeo, redMaterial);
  rightWing.position.set(1.31, 3.1, 0.1);
  rightWing.castShadow = true;
  rightWing.receiveShadow = true;
  chassis.add(rightWing);


  // -------------------- CREATE KART STEERING WHEEL ---------------------

  var stWheelGeo = new THREE.TorusGeometry(0.4, 0.1, 20, 20, Math.PI * 2);
  var wheelHolderGeo = new THREE.CylinderGeometry(0.07, 0.07, 2.2, 32);

  var stWheel = new THREE.Mesh(stWheelGeo, darkMaterial);
  stWheel.position.set(0, 0.4, 1.1);
  stWheel.rotateX(1.5708);
  stWheel.rotateX(-0.4);
  stWheel.castShadow = true;
  stWheel.receiveShadow = true;
  chassis.add(stWheel);


  var stwheelCenterGeo = new THREE.CylinderGeometry(0.3, 0.33, 0.05, 32);

  var stWheelCenter = new THREE.Mesh(stwheelCenterGeo, redMaterial);

  stWheelCenter.position.set(0, 0.4, 1.1);
  stWheelCenter.rotateX(-0.4);
  stWheelCenter.castShadow = true;
  stWheelCenter.receiveShadow = true;
  chassis.add(stWheelCenter);


  var stwheelHolderMat = new THREE.MeshPhongMaterial({ color: "rgb(140, 140, 140)" });
  var stwheelHolder = new THREE.Mesh(wheelHolderGeo, stwheelHolderMat);

  stwheelHolder.position.set(0, 1.40, 0.58);
  stwheelHolder.rotateX(-0.5);
  stwheelHolder.castShadow = true;
  stwheelHolder.receiveShadow = true;
  chassis.add(stwheelHolder);


  var stwheelCoverGeo = new THREE.BoxGeometry(0.7, 2.6, 0.1);

  var stwheelCover = new THREE.Mesh(stwheelCoverGeo, redMaterial);

  stwheelCover.position.set(0.0, 1.7, 0.6);
  stwheelCover.rotateX(-0.5);
  stwheelCover.castShadow = true;
  stwheelCover.receiveShadow = true;
  chassis.add(stwheelCover);

  var stwCoverSticker = new THREE.TextureLoader().load('./assets/kartTextures/45.png');
  var stwCoverGeo = new THREE.PlaneGeometry(0.7, 0.7);
  var stwCoverMat = new THREE.MeshPhongMaterial({ shininess: 50 });
  var stwcSticker = new THREE.Mesh(stwCoverGeo, stwCoverMat);
  stwcSticker.position.set(0, -0.3, 0.055);
  stwcSticker.rotateZ(degreesToRadians(180));
  stwcSticker.material.map = stwCoverSticker;
  stwcSticker.material.transparent = true;
  stwheelCover.add(stwcSticker);


  // -------------------- CREATE KART PEDALS ---------------------

  var pedalGeo = new THREE.BoxGeometry(0.3, 0.6, 0.03);
  var pedalMat = new THREE.MeshPhongMaterial({ color: "rgb(60,60,60)" });

  var gasPedal = new THREE.Mesh(pedalGeo, pedalMat);
  gasPedal.position.set(0.6, 2, 0.3);
  gasPedal.rotateX(0.4);
  gasPedal.castShadow = true;
  gasPedal.receiveShadow = true;
  chassis.add(gasPedal);

  var breakPedal = new THREE.Mesh(pedalGeo, pedalMat);
  breakPedal.position.set(-0.6, 2, 0.3);
  breakPedal.rotateX(0.4);
  breakPedal.castShadow = true;
  breakPedal.receiveShadow = true;
  chassis.add(breakPedal);


  // ----------------------- CREATE KART WHEELS -------------------------

  var wheelGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.6, 32);

  var flWheel = new THREE.Mesh(wheelGeo, darkMaterial);
  flWheel.position.set(-1.2, 2.0, 0);
  flWheel.rotateY(1.5708);
  flWheel.castShadow = true;
  flWheel.receiveShadow = true;
  chassis.add(flWheel);

  var frWheel = new THREE.Mesh(wheelGeo, darkMaterial);
  frWheel.position.set(1.2, 2.0, 0);
  frWheel.rotateY(1.5708);
  frWheel.castShadow = true;
  frWheel.receiveShadow = true;
  chassis.add(frWheel);

  var blWheel = new THREE.Mesh(wheelGeo, darkMaterial);
  blWheel.position.set(-1.2, -2.0, 0);
  blWheel.rotateZ(1.5708);
  blWheel.castShadow = true;
  blWheel.receiveShadow = true;
  chassis.add(blWheel);

  var brWheel = new THREE.Mesh(wheelGeo, darkMaterial);
  brWheel.position.set(1.2, -2.0, 0);
  brWheel.rotateZ(1.5708);
  brWheel.castShadow = true;
  brWheel.receiveShadow = true;
  chassis.add(brWheel);


  // ----------------------- CREATE KART AXLE -------------------------

  const wheelAxleGeo = new THREE.CylinderGeometry(0.09, 0.09, 2.3, 32);
  const wheelAxleFront = new THREE.Mesh(wheelAxleGeo, greyMaterial);
  wheelAxleFront.position.set(0, 2, -0.01);
  wheelAxleFront.rotateZ(1.5708);
  wheelAxleFront.castShadow = true;
  wheelAxleFront.receiveShadow = true;
  chassis.add(wheelAxleFront);

  const wheelAxleBack = new THREE.Mesh(wheelAxleGeo, greyMaterial);
  wheelAxleBack.position.set(0, -2, -0.01);
  wheelAxleBack.rotateZ(1.5708);
  wheelAxleBack.castShadow = true;
  wheelAxleBack.receiveShadow = true;
  chassis.add(wheelAxleBack);

  // ===================== END OF CREATE KART =============================



  // ------------------ CAMERA HANDLING ----------------------
  // camera aways looking to kart position
  function updateCamera() {

    camera.fov = 50;
    camera.updateProjectionMatrix();

    camera.up.set(0, 0, 1);

    if (!freeCameraMode) {

      camera.position.copy(new THREE.Vector3(0, -20 - zoomFactorY, 5 + zoomFactorZ));

      camera.lookAt(kartSoul.position.x, kartSoul.position.y, kartSoul.position.z + 3);

    }
    else {
      camera.lookAt(kartSoul.position.x, kartSoul.position.y, kartSoul.position.z);
    }


    //update light position to follow camera
    spotLight.target = camera;

  }

  // reset camera position (used after camera mode switch)
  function resetCamera() {

    zoomFactorY = -3.0;
    zoomFactorZ = -0.3;

    camera.lookAt(kartSoul.position.x, kartSoul.position.y, kartSoul.position.z);
    camera.position.copy(new THREE.Vector3(0, -25, 5));

    updateCamera();
  }

  // reset camera position (used after camera mode switch)
  function setCockPitMode() {

    cockPitMode = true;

    camera.position.copy(new THREE.Vector3(0, -3, 2.7));

    camera.up.set(0, 0, 1);

    camera.lookAt(kartSoul.position.x, kartSoul.position.y, kartSoul.position.z + 2.2);

    camera.fov = 55;
    camera.updateProjectionMatrix();


  }
  // ------------------ END OF CAMERA HANDLING ----------------------



  // ----------------- HANDLE KART TURN ----------------
  // Kart turn
  var shouldTurn = false;

  function turnKart(side) {

    if (side == "left" && shouldTurn) {
      if (turnAngle <= 0.4) {
        turnAngle += 0.02;
      }
    }
    else if (side == "right" && shouldTurn) {
      if (turnAngle >= -0.4) {
        turnAngle -= 0.02;
      }
    }

  }

  // Kart Wheels turn animation
  function animateWheels() {

    // keep the kart centered if not turning
    if (shouldTurn == false) {
      if (turnAngle > 0) {
        turnAngle -= 0.02;
      }
      else if (turnAngle < 0) {
        turnAngle += 0.02;
      }
      else {
        turnAngle = 0.0;
      }
    }

    flWheel.matrixAutoUpdate = false;

    frWheel.matrixAutoUpdate = false;

    var mat4 = new THREE.Matrix4();

    flWheel.matrix.identity();

    flWheel.matrix.multiply(mat4.makeTranslation(-1.24, 2, 0));

    flWheel.matrix.multiply(mat4.makeRotationZ(1.57));

    // left wheel turn angle
    flWheel.matrix.multiply(mat4.makeRotationZ(turnAngle));



    frWheel.matrix.identity();

    frWheel.matrix.multiply(mat4.makeTranslation(1.24, 2, 0));

    frWheel.matrix.multiply(mat4.makeRotationZ(1.57));

    // right wheel turn angle
    frWheel.matrix.multiply(mat4.makeRotationZ(turnAngle));

  }

  // --------------- END HANDLE KART TURN ---------------




  // ------------- HANDLE FORWARD KART MOVEMENT (speed) -----------


  // Keep updating speed on screen
  var intervalSpeedUpdate = window.setInterval(updateSpeedOnScreen, 100);
  function updateSpeedOnScreen() {

    var camMessage = "Gameplay";

    if (!freeCameraMode) {

      if (cockPitMode) {
        camMessage = "Cockpit";
      }
      else {
        camMessage = "Gameplay";
      }

      if (kartSpeed != 0) {
        message.changeMessage("Camera mode: " + camMessage + "; Kart Speed: " + Math.abs(kartSpeed).toFixed(2));
      }
      else {
        message.changeMessage("Camera mode: " + camMessage + "; Kart Speed: 0.0");
      }

    }

  }


  // Aways update kart position to given speed
  function handleKartSpeed() {

    kartSoul.translateY(kartSpeed);

    delta = clock.getDelta();

    // If not in FreeCamera
    if (!freeCameraMode) {

      // If speed is greater then 0, decrease it gradually

      if (kartSpeed > 0) {

        kartSpeed -= 0.2 * delta;

      }

      else if (kartSpeed < 0.0 && kartSpeed > -maxSpeed) {

        kartSpeed += 0.2 * delta;

      }

      else if (kartSpeed > 0.1 && kartSpeed < -0.1) {
        kartSpeed = 0.0;
      }

    }

  }

  // ============== READ KEYBOARD INPUTS AND MAP ITS ACTIONS ===================
  function keyboardUpdate() {

    keyboard.update();

    // Call car controls function (acceleration, break, turn)
    kartControls(angleMov, rotAxis);

    // handle camera - switch  between freecamera and gameplay camera
    if (keyboard.down("space")) {

      // If in free camera mode, attach the camera back to the kart 
      if (freeCameraMode) {
        resetCamera();
        plane.visible = true;
        pole1.visible = true;
        pole2.visible = true;
        pole3.visible = true;
        pole4.visible = true;
        pole5.visible = true;
        pole6.visible = true;
        pole7.visible = true;
        pole8.visible = true;
        statue_group.visible = true;
        mtn1_group.visible = true;
        mtn2_group.visible = true;
        traffic_light.visible = true;
        tree_group.visible = true;
        cactus_group.visible = true;

        freeCameraMode = false;

        kartSpeed = 0.0; // reset kart speed
      }

      // If not in free camera mode, check if its on cockpit mode. Apply cockpit mode if its not
      else {

        if (!cockPitMode) {
          setCockPitMode();
        }

        else {
          cockPitMode = false;
          resetCamera();
          message.changeMessage("Camera mode: FreeCamera");
          plane.visible = false;
          pole1.visible = false;
          pole2.visible = false;
          pole3.visible = false;
          pole4.visible = false;
          pole5.visible = false;
          pole6.visible = false;
          pole7.visible = false;
          pole8.visible = false;
          statue_group.visible = false;
          mtn1_group.visible = false;
          mtn2_group.visible = false;
          traffic_light.visible = false;
          tree_group.visible = false;
          cactus_group.visible = false;

          kartSpeed = 0.0; // reset kart speed

          freeCameraMode = true; // switch camera mode

        }

      }


    }

    if (keyboard.down("A")) {
      if (!planeMode) {
        message.changeMessage("Camera mode: Plane mode");
        kartSpeed = 0.0;
      }
      else {
        message.changeMessage("Camera mode: Gameplay");
        resetCamera();
      }

      planeMode = !planeMode;
    }

    if (keyboard.down("A")) {

    }
  }


  // Handle kart controls
  function kartControls(angleMov, rotAxis) {

    // turn left
    if (keyboard.pressed("left")) {

      if (kartSpeed < -0.01) {
        shouldTurn = true;
        turnKart("left");
        if (!freeCameraMode) {
          kartSoul.rotateOnAxis(rotAxis, -angleMov);
        }
      }

      else {
        shouldTurn = true;
        turnKart("left");
        if (!freeCameraMode) {
          kartSoul.rotateOnAxis(rotAxis, angleMov);
        }
      }

    };

    if (keyboard.up("left")) {
      shouldTurn = false;
    };

    // turn right
    if (keyboard.pressed("right")) {

      if (kartSpeed < -0.01) {
        shouldTurn = true;
        turnKart("right");
        if (!freeCameraMode) {
          kartSoul.rotateOnAxis(rotAxis, angleMov);
        }
      }

      else {
        shouldTurn = true;
        turnKart("right");
        if (!freeCameraMode) {
          kartSoul.rotateOnAxis(rotAxis, -angleMov);
        }
      }
    };

    if (keyboard.up("right")) {
      shouldTurn = false;
    };

    // acceleration
    if (keyboard.pressed("up")) {

      if (!freeCameraMode) {

        if (kartSpeed <= maxSpeed) {
          kartSpeed += 0.01;
        }

      }

    };

    // break
    if (keyboard.pressed("down")) {

      if (!freeCameraMode) {

        if (kartSpeed > -maxSpeed) {
          kartSpeed -= 0.010;
        }
        // else if (kartSpeed <= 0.0) {
        //   kartSpeed = 0;
        // }

      }

    };

    if (keyboard.pressed("B")) {
      textureRepeat += 0.01;
      auxPlane.material.map.repeat.set(textureRepeat, textureRepeat);
    };

    if (keyboard.pressed("N")) {
      textureRepeat -= 0.01;
      auxPlane.material.map.repeat.set(textureRepeat, textureRepeat);
    };

  }

  // ============== END KEYBOARD INPUTS AND MAP ACTIONS ===================



  // ============== MOUNTAIN DEFINITIONS ===================

  function pointsMtn1_0() {

    var points = [];

    // Base of Mountain 1
    points.push(new THREE.Vector3(-32.031, 77.757, 59.865));
    points.push(new THREE.Vector3(-31.384, 51.553, 36.089));
    points.push(new THREE.Vector3(-46.835, 51.553, 36.089));
    points.push(new THREE.Vector3(-59.335, 51.553, 45.171));
    points.push(new THREE.Vector3(-46.835, 51.553, 83.642));
    points.push(new THREE.Vector3(-31.384, 51.553, 83.642));
    points.push(new THREE.Vector3(-16.500, 47.251, 78.211));
    points.push(new THREE.Vector3(-39.110, 1.553, 59.865));
    points.push(new THREE.Vector3(1.341, 1.553, 30.476));
    points.push(new THREE.Vector3(10.890, 1.553, 59.865));
    points.push(new THREE.Vector3(-23.659, 1.553, 12.313));
    points.push(new THREE.Vector3(-54.561, 1.553, 12.313));
    points.push(new THREE.Vector3(-79.561, 1.553, 30.476));
    points.push(new THREE.Vector3(-89.110, 1.553, 59.865));
    points.push(new THREE.Vector3(-79.561, 1.553, 89.255));
    points.push(new THREE.Vector3(-54.561, 1.553, 107.418));
    points.push(new THREE.Vector3(-23.659, 1.553, 107.418));
    points.push(new THREE.Vector3(1.341, 1.553, 89.255));
    points.push(new THREE.Vector3(-59.335, 51.553, 74.560));
    points.push(new THREE.Vector3(-47.148, 70.411, 64.732));
    points.push(new THREE.Vector3(-64.110, 51.553, 59.865));
    points.push(new THREE.Vector3(-44.257, 61.037, 67.965));
    points.push(new THREE.Vector3(-50.214, 65.868, 59.865));
    points.push(new THREE.Vector3(-13.206, 30.076, 92.901));
    points.push(new THREE.Vector3(-1.922, 40.543, 71.487));
    points.push(new THREE.Vector3(-3.715, 51.553, 59.865));
    points.push(new THREE.Vector3(-1.605, 36.799, 50.015));
    points.push(new THREE.Vector3(-18.884, 51.553, 45.171));
    points.push(new THREE.Vector3(-16.169, 28.750, 22.437));
    points.push(new THREE.Vector3(-39.200, 32.710, 22.373));
    points.push(new THREE.Vector3(-66.500, 23.898, 25.105));
    points.push(new THREE.Vector3(-71.900, 38.931, 49.030));
    points.push(new THREE.Vector3(-84.393, 23.385, 74.008));
    points.push(new THREE.Vector3(-59.333, 40.889, 86.707));
    points.push(new THREE.Vector3(-41.022, 27.408, 102.891));
    points.push(new THREE.Vector3(-19.744, 66.409, 64.563));
    points.push(new THREE.Vector3(-21.577, 67.862, 54.671));
    points.push(new THREE.Vector3(-28.375, 65.986, 47.957));


    // SE QUISER MOSTRAR OS PONTOS (pode dar erro ao mexer na escala)
    //showPoints(points);

    return points;

  }

  function pointsMtn1_1() {

    var points = [];

    // Base of Mountain 1
    points.push(new THREE.Vector3(-41.131, 76.552, 98.523));
    points.push(new THREE.Vector3(-40.484, 50.348, 74.747));
    points.push(new THREE.Vector3(-55.935, 50.348, 74.747));
    points.push(new THREE.Vector3(-68.435, 50.348, 83.829));
    points.push(new THREE.Vector3(-55.935, 50.348, 122.300));
    points.push(new THREE.Vector3(-40.484, 50.348, 122.300));
    points.push(new THREE.Vector3(-48.209, 0.348, 98.523));
    points.push(new THREE.Vector3(-37.821, 0.348, 97.411));
    points.push(new THREE.Vector3(-27.821, 0.348, 97.411));
    points.push(new THREE.Vector3(-37.821, 0.348, 87.411));
    points.push(new THREE.Vector3(-47.821, 0.348, 77.411));
    points.push(new THREE.Vector3(-57.821, 0.348, 87.411));
    points.push(new THREE.Vector3(-67.821, 0.348, 97.411));
    points.push(new THREE.Vector3(-53.835, 0.348, 103.941));
    points.push(new THREE.Vector3(-44.049, 0.348, 110.091));
    points.push(new THREE.Vector3(-45.757, 7.620, 118.939));
    points.push(new THREE.Vector3(-27.821, 0.348, 117.411));
    points.push(new THREE.Vector3(-68.435, 50.348, 113.218));
    points.push(new THREE.Vector3(-56.248, 69.206, 103.390));
    points.push(new THREE.Vector3(-73.209, 50.348, 98.523));
    points.push(new THREE.Vector3(-53.356, 59.832, 106.624));
    points.push(new THREE.Vector3(-59.314, 64.663, 98.523));
    points.push(new THREE.Vector3(-26.254, 32.574, 112.106));
    points.push(new THREE.Vector3(-25.599, 46.046, 116.869));
    points.push(new THREE.Vector3(-25.743, 43.095, 116.904));
    points.push(new THREE.Vector3(-10.705, 35.594, 88.674));
    points.push(new THREE.Vector3(-63.170, 14.536, 125.151));
    points.push(new THREE.Vector3(-48.300, 31.505, 61.032));
    points.push(new THREE.Vector3(-61.563, 0.348, 81.689));
    points.push(new THREE.Vector3(-80.999, 37.727, 87.688));
    points.push(new THREE.Vector3(-68.432, 39.685, 125.365));
    points.push(new THREE.Vector3(-34.671, 9.846, 116.937));
    points.push(new THREE.Vector3(-12.815, 50.348, 98.523));
    points.push(new THREE.Vector3(-28.844, 65.204, 103.221));
    points.push(new THREE.Vector3(-30.677, 66.657, 93.329));
    points.push(new THREE.Vector3(-27.984, 50.348, 83.829));
    points.push(new THREE.Vector3(-37.475, 64.781, 86.615));


    // SE QUISER MOSTRAR OS PONTOS (pode dar erro ao mexer na escala)
    //showPoints(points);

    return points;

  }

  function pointsMtn1_2() {

    var points = [];

    // Base of Mountain 1

    points.push(new THREE.Vector3(22.021, 50.000, -73.384));
    points.push(new THREE.Vector3(14.551, 37.287, -62.583));
    points.push(new THREE.Vector3(30.727, 1.995, -45.232));
    points.push(new THREE.Vector3(32.008, -0.000, -42.290));
    points.push(new THREE.Vector3(34.998, 33.109, -66.288));
    points.push(new THREE.Vector3(72.008, -0.000, -62.290));
    points.push(new THREE.Vector3(9.915, 86.230, -97.160));
    points.push(new THREE.Vector3(39.295, 50.000, -97.160));
    points.push(new THREE.Vector3(34.521, 50.000, -111.855));
    points.push(new THREE.Vector3(22.021, 50.000, -120.936));
    points.push(new THREE.Vector3(6.570, 50.000, -120.936));
    points.push(new THREE.Vector3(-5.930, 50.000, -111.855));
    points.push(new THREE.Vector3(-17.127, 50.000, -97.160));
    points.push(new THREE.Vector3(-11.853, 52.393, -86.806));
    points.push(new THREE.Vector3(6.570, 50.000, -67.709));
    points.push(new THREE.Vector3(34.521, 50.000, -82.465));
    points.push(new THREE.Vector3(14.295, 0.000, -97.160));
    points.push(new THREE.Vector3(72.008, 0.000, -115.987));
    points.push(new THREE.Vector3(82.008, 0.000, -92.290));
    points.push(new THREE.Vector3(42.008, 0.000, -137.826));
    points.push(new THREE.Vector3(2.008, -0.000, -142.290));
    points.push(new THREE.Vector3(-33.150, 0.000, -129.170));
    points.push(new THREE.Vector3(-53.150, 0.000, -99.170));
    points.push(new THREE.Vector3(-36.156, 0.000, -67.771));
    points.push(new THREE.Vector3(-13.150, -0.000, -39.170));
    points.push(new THREE.Vector3(-15.261, 31.319, -64.165));
    points.push(new THREE.Vector3(50.940, 36.792, -85.908));
    points.push(new THREE.Vector3(57.564, 35.000, -104.827));
    points.push(new THREE.Vector3(45.021, 35.948, -120.956));
    points.push(new THREE.Vector3(17.512, 21.471, -137.970));
    points.push(new THREE.Vector3(-8.222, 35.256, -124.606));
    points.push(new THREE.Vector3(-19.624, 40.476, -108.181));
    points.push(new THREE.Vector3(-27.671, 35.777, -81.403));


    // SE QUISER MOSTRAR OS PONTOS (pode dar erro ao mexer na escala)
    //showPoints(points);

    return points;

  }

  function pointsMtn1_3() {

    var points = [];

    // Base of Mountain 1
    points.push(new THREE.Vector3(1.119, 72.314, -88.690));
    points.push(new THREE.Vector3(-9.399, 46.314, -81.049));
    points.push(new THREE.Vector3(0.735, 59.314, -81.328));
    points.push(new THREE.Vector3(3.601, 46.314, -71.604));
    points.push(new THREE.Vector3(7.619, 72.314, -83.967));
    points.push(new THREE.Vector3(11.619, 61.699, -78.920));
    points.push(new THREE.Vector3(19.670, 46.314, -71.604));
    points.push(new THREE.Vector3(15.653, 72.314, -83.967));
    points.push(new THREE.Vector3(22.476, 61.850, -82.774));
    points.push(new THREE.Vector3(32.670, 46.314, -81.049));
    points.push(new THREE.Vector3(22.153, 72.314, -88.690));
    points.push(new THREE.Vector3(28.017, 62.302, -91.332));
    points.push(new THREE.Vector3(37.636, 46.314, -96.331));
    points.push(new THREE.Vector3(24.636, 72.314, -96.331));
    points.push(new THREE.Vector3(27.616, 63.324, -101.968));
    points.push(new THREE.Vector3(32.670, 46.314, -111.614));
    points.push(new THREE.Vector3(22.153, 72.314, -103.972));
    points.push(new THREE.Vector3(21.638, 61.686, -112.483));
    points.push(new THREE.Vector3(19.670, 46.314, -121.059));
    points.push(new THREE.Vector3(15.653, 72.314, -108.695));
    points.push(new THREE.Vector3(11.358, 62.284, -114.612));
    points.push(new THREE.Vector3(3.601, 46.314, -121.059));
    points.push(new THREE.Vector3(7.619, 72.314, -108.695));
    points.push(new THREE.Vector3(1.192, 62.070, -110.080));
    points.push(new THREE.Vector3(-9.399, 46.314, -111.614));
    points.push(new THREE.Vector3(1.119, 72.314, -103.972));
    points.push(new THREE.Vector3(-6.492, 61.668, -101.560));
    points.push(new THREE.Vector3(-14.364, 46.314, -96.331));
    points.push(new THREE.Vector3(-1.364, 72.314, -96.331));
    points.push(new THREE.Vector3(-5.189, 61.387, -90.035));
    points.push(new THREE.Vector3(11.636, 89.897, -95.717));
    points.push(new THREE.Vector3(11.636, 46.314, -96.331));
    points.push(new THREE.Vector3(11.855, 83.888, -89.471));
    points.push(new THREE.Vector3(6.797, 81.993, -90.254));

    // SE QUISER MOSTRAR OS PONTOS (pode dar erro ao mexer na escala)
    //showPoints(points);

    return points;

  }

  function pointsMtn1_4() {

    var points = [];

    // Base of Mountain 1
    points.push(new THREE.Vector3(132.551, 1.995, 155.964));
    points.push(new THREE.Vector3(123.845, 50.000, 139.340));
    points.push(new THREE.Vector3(116.375, 37.287, 150.141));
    points.push(new THREE.Vector3(113.832, -0.000, 158.361));
    points.push(new THREE.Vector3(150.000, -0.000, 150.000));
    points.push(new THREE.Vector3(136.823, 33.109, 146.436));
    points.push(new THREE.Vector3(111.740, 81.690, 115.564));
    points.push(new THREE.Vector3(141.120, 50.000, 115.564));
    points.push(new THREE.Vector3(136.345, 50.000, 100.869));
    points.push(new THREE.Vector3(123.845, 50.000, 91.787));
    points.push(new THREE.Vector3(108.394, 50.000, 91.787));
    points.push(new THREE.Vector3(95.894, 50.000, 100.869));
    points.push(new THREE.Vector3(84.698, 50.000, 115.564));
    points.push(new THREE.Vector3(89.971, 52.393, 125.918));
    points.push(new THREE.Vector3(108.394, 50.000, 145.014));
    points.push(new THREE.Vector3(136.345, 50.000, 130.258));
    points.push(new THREE.Vector3(116.120, -0.000, 115.564));
    points.push(new THREE.Vector3(164.461, -0.000, 100.000));
    points.push(new THREE.Vector3(170.000, -0.000, 120.000));
    points.push(new THREE.Vector3(143.832, 0.000, 84.898));
    points.push(new THREE.Vector3(103.832, -0.000, 74.408));
    points.push(new THREE.Vector3(68.674, -0.000, 84.966));
    points.push(new THREE.Vector3(55.950, -0.000, 113.554));
    points.push(new THREE.Vector3(65.669, -0.000, 144.953));
    points.push(new THREE.Vector3(88.674, -0.000, 153.554));
    points.push(new THREE.Vector3(86.564, 31.319, 148.559));
    points.push(new THREE.Vector3(152.764, 36.792, 126.816));
    points.push(new THREE.Vector3(149.388, 35.000, 107.897));
    points.push(new THREE.Vector3(140.888, 35.948, 92.909));
    points.push(new THREE.Vector3(119.337, 21.471, 79.243));
    points.push(new THREE.Vector3(93.603, 35.256, 88.118));
    points.push(new THREE.Vector3(82.201, 40.476, 104.543));
    points.push(new THREE.Vector3(74.153, 35.777, 131.321));



    // SE QUISER MOSTRAR OS PONTOS (pode dar erro ao mexer na escala)
    //showPoints(points);

    return points;

  }

  function pointsMtn1_5() {

    var points = [];

    // Base of Mountain 1
    points.push(new THREE.Vector3(101.843, 72.656, 126.312));
    points.push(new THREE.Vector3(91.326, 46.656, 133.953));
    points.push(new THREE.Vector3(101.459, 59.656, 133.675));
    points.push(new THREE.Vector3(104.326, 46.656, 143.398));
    points.push(new THREE.Vector3(108.343, 72.656, 131.035));
    points.push(new THREE.Vector3(112.343, 62.041, 136.082));
    points.push(new THREE.Vector3(120.395, 46.656, 143.398));
    points.push(new THREE.Vector3(116.377, 72.656, 131.035));
    points.push(new THREE.Vector3(123.200, 62.192, 132.228));
    points.push(new THREE.Vector3(133.395, 46.656, 133.953));
    points.push(new THREE.Vector3(122.877, 76.927, 126.312));
    points.push(new THREE.Vector3(128.741, 62.644, 123.670));
    points.push(new THREE.Vector3(143.421, 39.720, 118.671));
    points.push(new THREE.Vector3(125.360, 76.675, 118.671));
    points.push(new THREE.Vector3(128.340, 63.666, 113.034));
    points.push(new THREE.Vector3(133.395, 46.656, 103.388));
    points.push(new THREE.Vector3(122.877, 72.656, 111.030));
    points.push(new THREE.Vector3(122.362, 62.028, 102.519));
    points.push(new THREE.Vector3(120.395, 46.656, 93.943));
    points.push(new THREE.Vector3(116.377, 72.656, 106.307));
    points.push(new THREE.Vector3(112.082, 62.626, 100.390));
    points.push(new THREE.Vector3(104.326, 46.656, 93.943));
    points.push(new THREE.Vector3(108.343, 72.656, 106.307));
    points.push(new THREE.Vector3(101.916, 62.412, 104.922));
    points.push(new THREE.Vector3(91.326, 46.656, 103.388));
    points.push(new THREE.Vector3(101.843, 72.656, 111.030));
    points.push(new THREE.Vector3(94.233, 62.010, 113.442));
    points.push(new THREE.Vector3(86.360, 46.656, 118.671));
    points.push(new THREE.Vector3(99.360, 72.656, 118.671));
    points.push(new THREE.Vector3(95.535, 61.729, 124.967));
    points.push(new THREE.Vector3(112.360, 82.728, 114.485));
    points.push(new THREE.Vector3(112.360, 46.656, 118.671));
    points.push(new THREE.Vector3(111.676, 77.934, 125.531));
    points.push(new THREE.Vector3(107.521, 81.606, 122.747));


    // SE QUISER MOSTRAR OS PONTOS (pode dar erro ao mexer na escala)
    //showPoints(points);

    return points;

  }


  function pointsMtn2_0() {

    var points = [];

    points.push(new THREE.Vector3(12.008, -0.000, -42.290));
    points.push(new THREE.Vector3(30.727, 1.995, -49.272));
    points.push(new THREE.Vector3(22.021, 50.000, -73.384));
    points.push(new THREE.Vector3(14.551, 37.287, -62.583));
    points.push(new THREE.Vector3(52.008, -0.000, -62.290));
    points.push(new THREE.Vector3(34.998, 33.109, -66.288));
    points.push(new THREE.Vector3(9.915, 79.372, -97.160));
    points.push(new THREE.Vector3(39.295, 50.000, -97.160));
    points.push(new THREE.Vector3(34.521, 50.000, -111.855));
    points.push(new THREE.Vector3(22.021, 50.000, -120.936));
    points.push(new THREE.Vector3(6.570, 50.000, -120.936));
    points.push(new THREE.Vector3(-5.930, 50.000, -111.855));
    points.push(new THREE.Vector3(-17.127, 50.000, -97.160));
    points.push(new THREE.Vector3(-11.853, 52.393, -86.806));
    points.push(new THREE.Vector3(6.570, 50.000, -67.709));
    points.push(new THREE.Vector3(34.521, 50.000, -82.465));
    points.push(new THREE.Vector3(14.295, 0.000, -97.160));
    points.push(new THREE.Vector3(62.008, 0.000, -115.987));
    points.push(new THREE.Vector3(72.008, 0.000, -92.290));
    points.push(new THREE.Vector3(42.008, 0.000, -137.826));
    points.push(new THREE.Vector3(2.008, -0.000, -142.290));
    points.push(new THREE.Vector3(-33.150, 0.000, -129.170));
    points.push(new THREE.Vector3(-53.150, 0.000, -99.170));
    points.push(new THREE.Vector3(-46.156, -0.000, -57.771));
    points.push(new THREE.Vector3(-13.150, -0.000, -49.170));
    points.push(new THREE.Vector3(-15.261, 31.319, -64.165));
    points.push(new THREE.Vector3(50.940, 32.231, -85.908));
    points.push(new THREE.Vector3(57.564, 25.000, -104.827));
    points.push(new THREE.Vector3(38.876, 35.948, -120.956));
    points.push(new THREE.Vector3(17.512, 21.471, -137.970));
    points.push(new THREE.Vector3(-8.222, 35.256, -124.606));
    points.push(new THREE.Vector3(-19.624, 40.476, -108.181));
    points.push(new THREE.Vector3(-37.671, 27.950, -81.403));


    return points;

  }

  function pointsMtn2_1() {

    var points = [];

    points.push(new THREE.Vector3(2.306, 69.609, -88.690));
    points.push(new THREE.Vector3(-9.399, 46.314, -78.594));
    points.push(new THREE.Vector3(0.735, 59.314, -81.328));
    points.push(new THREE.Vector3(2.830, 46.314, -68.515));
    points.push(new THREE.Vector3(7.619, 72.314, -83.967));
    points.push(new THREE.Vector3(11.619, 61.699, -78.920));
    points.push(new THREE.Vector3(19.670, 46.314, -71.604));
    points.push(new THREE.Vector3(15.653, 72.314, -83.967));
    points.push(new THREE.Vector3(22.476, 61.850, -82.774));
    points.push(new THREE.Vector3(32.670, 46.314, -81.049));
    points.push(new THREE.Vector3(22.153, 72.314, -88.690));
    points.push(new THREE.Vector3(28.017, 62.302, -91.332));
    points.push(new THREE.Vector3(37.636, 46.314, -96.331));
    points.push(new THREE.Vector3(24.636, 72.314, -96.331));
    points.push(new THREE.Vector3(27.616, 63.324, -101.968));
    points.push(new THREE.Vector3(32.670, 46.314, -111.614));
    points.push(new THREE.Vector3(22.153, 72.314, -103.972));
    points.push(new THREE.Vector3(21.638, 61.686, -112.483));
    points.push(new THREE.Vector3(19.670, 46.314, -121.059));
    points.push(new THREE.Vector3(15.653, 72.314, -108.695));
    points.push(new THREE.Vector3(11.358, 62.284, -114.612));
    points.push(new THREE.Vector3(3.601, 46.314, -121.059));
    points.push(new THREE.Vector3(7.619, 72.314, -108.695));
    points.push(new THREE.Vector3(1.192, 62.070, -110.080));
    points.push(new THREE.Vector3(-9.399, 46.314, -111.614));
    points.push(new THREE.Vector3(1.119, 72.314, -103.972));
    points.push(new THREE.Vector3(-6.492, 61.668, -101.560));
    points.push(new THREE.Vector3(-14.364, 46.314, -96.331));
    points.push(new THREE.Vector3(0.129, 72.812, -96.331));
    points.push(new THREE.Vector3(-5.189, 61.387, -90.035));
    points.push(new THREE.Vector3(15.349, 85.876, -95.717));
    points.push(new THREE.Vector3(11.636, 46.314, -96.331));
    points.push(new THREE.Vector3(11.855, 78.883, -89.471));
    points.push(new THREE.Vector3(9.665, 78.879, -90.254));
    points.push(new THREE.Vector3(6.712, 81.625, -98.285));
    points.push(new THREE.Vector3(6.907, 80.728, -94.179));
    points.push(new THREE.Vector3(6.358, 82.081, -96.024));

    return points;

  }

  function pointsMtn2_2() {

    var points = [];

    points.push(new THREE.Vector3(20.000, -0.000, -50.000));
    points.push(new THREE.Vector3(25.672, -0.000, -50.981));
    points.push(new THREE.Vector3(22.021, 55.774, -75.591));
    points.push(new THREE.Vector3(14.551, 37.287, -62.583));
    points.push(new THREE.Vector3(52.028, 0.000, -60.000));
    points.push(new THREE.Vector3(34.998, 33.109, -66.288));
    points.push(new THREE.Vector3(39.295, 50.000, -97.160));
    points.push(new THREE.Vector3(25.901, 61.202, -97.160));
    points.push(new THREE.Vector3(22.134, 69.847, -93.235));
    points.push(new THREE.Vector3(34.521, 50.000, -82.465));
    points.push(new THREE.Vector3(34.521, 50.000, -111.855));
    points.push(new THREE.Vector3(23.571, 64.293, -105.315));
    points.push(new THREE.Vector3(22.021, 50.000, -120.936));
    points.push(new THREE.Vector3(16.628, 60.946, -110.345));
    points.push(new THREE.Vector3(6.570, 50.000, -120.936));
    points.push(new THREE.Vector3(7.897, 59.750, -111.502));
    points.push(new THREE.Vector3(-10.186, 50.000, -111.855));
    points.push(new THREE.Vector3(2.091, 66.975, -105.907));
    points.push(new THREE.Vector3(-17.127, 50.000, -97.160));
    points.push(new THREE.Vector3(-6.077, 60.041, -97.160));
    points.push(new THREE.Vector3(-7.897, 56.903, -86.806));
    points.push(new THREE.Vector3(-4.015, 62.863, -90.534));
    points.push(new THREE.Vector3(7.627, 56.179, -71.825));
    points.push(new THREE.Vector3(8.066, 67.186, -80.882));
    points.push(new THREE.Vector3(18.301, 67.550, -83.976));
    points.push(new THREE.Vector3(14.295, 0.000, -97.160));
    points.push(new THREE.Vector3(62.008, 0.000, -115.987));
    points.push(new THREE.Vector3(66.382, 0.000, -92.290));
    points.push(new THREE.Vector3(42.008, 0.000, -137.826));
    points.push(new THREE.Vector3(2.008, -0.000, -142.290));
    points.push(new THREE.Vector3(-16.185, 0.000, -124.645));
    points.push(new THREE.Vector3(-33.150, 0.000, -99.170));
    points.push(new THREE.Vector3(-39.208, 0.000, -67.771));
    points.push(new THREE.Vector3(-13.150, -0.000, -49.170));
    points.push(new THREE.Vector3(-15.261, 31.319, -64.165));
    points.push(new THREE.Vector3(50.940, 32.231, -85.908));
    points.push(new THREE.Vector3(57.564, 25.000, -104.827));
    points.push(new THREE.Vector3(38.876, 35.948, -120.956));
    points.push(new THREE.Vector3(17.512, 21.471, -137.970));
    points.push(new THREE.Vector3(-8.222, 35.256, -124.606));
    points.push(new THREE.Vector3(-19.624, 40.476, -108.181));
    points.push(new THREE.Vector3(-27.671, 23.961, -81.403));
    points.push(new THREE.Vector3(9.915, 64.572, -97.160));


    return points;

  }

  function pointsMtn2_3() {

    var points = [];

    points.push(new THREE.Vector3(2.306, 67.182, -88.690));
    points.push(new THREE.Vector3(-9.399, 43.887, -78.594));
    points.push(new THREE.Vector3(1.663, 56.887, -82.149));
    points.push(new THREE.Vector3(2.830, 43.887, -68.515));
    points.push(new THREE.Vector3(7.619, 69.887, -83.967));
    points.push(new THREE.Vector3(11.619, 59.272, -77.363));
    points.push(new THREE.Vector3(19.670, 43.887, -71.604));
    points.push(new THREE.Vector3(15.653, 69.887, -83.967));
    points.push(new THREE.Vector3(22.476, 59.423, -81.485));
    points.push(new THREE.Vector3(32.670, 43.887, -81.049));
    points.push(new THREE.Vector3(22.153, 69.887, -88.690));
    points.push(new THREE.Vector3(28.017, 59.875, -89.938));
    points.push(new THREE.Vector3(37.636, 43.887, -96.331));
    points.push(new THREE.Vector3(24.636, 69.887, -96.331));
    points.push(new THREE.Vector3(30.413, 60.898, -101.968));
    points.push(new THREE.Vector3(32.670, 43.887, -111.614));
    points.push(new THREE.Vector3(22.153, 69.887, -103.972));
    points.push(new THREE.Vector3(21.638, 59.260, -114.292));
    points.push(new THREE.Vector3(19.670, 43.887, -121.059));
    points.push(new THREE.Vector3(15.653, 69.887, -108.695));
    points.push(new THREE.Vector3(11.358, 59.857, -116.885));
    points.push(new THREE.Vector3(3.601, 43.887, -121.059));
    points.push(new THREE.Vector3(7.619, 69.887, -108.695));
    points.push(new THREE.Vector3(1.192, 59.643, -111.765));
    points.push(new THREE.Vector3(-9.399, 43.887, -111.614));
    points.push(new THREE.Vector3(1.119, 69.887, -103.972));
    points.push(new THREE.Vector3(-8.895, 59.241, -101.560));
    points.push(new THREE.Vector3(-14.364, 43.887, -96.331));
    points.push(new THREE.Vector3(0.129, 70.385, -96.331));
    points.push(new THREE.Vector3(-6.963, 58.961, -90.035));
    points.push(new THREE.Vector3(15.349, 81.022, -95.717));
    points.push(new THREE.Vector3(6.712, 76.997, -98.285));
    points.push(new THREE.Vector3(6.358, 77.178, -96.024));
    points.push(new THREE.Vector3(6.907, 78.301, -94.179));
    points.push(new THREE.Vector3(11.636, 43.887, -96.331));
    points.push(new THREE.Vector3(11.855, 76.456, -89.471));
    points.push(new THREE.Vector3(9.665, 76.453, -90.254));


    return points;

  }


  function createMountain1() {

    // =============== Mountain 1 PT 0 ===============

    mtn1_0_obj = createMtnObj(pointsMtn1_0(), mountainMaterial);

    mtn1_0_obj.translateX(-14);
    mtn1_0_obj.translateZ(2.5);
    mtn1_0_obj.translateY(-0.15);

    mtn1_0_obj.rotateY(90);

    mtn1_group.add(mtn1_0_obj);


    // =============== Mountain 1 PT 1 ===============

    mtn1_1_obj = createMtnObj(pointsMtn1_1(), mountainTipMaterial);

    mtn1_1_obj.translateX(10);
    mtn1_1_obj.translateZ(-39);
    mtn1_1_obj.translateY(1.5);

    mtn1_1_obj.scale.set(1.01, 1.01, 1.01);

    mtn1_0_obj.add(mtn1_1_obj);


    // =============== Mountain 1 PT 2 ===============

    mtn1_2_obj = createMtnObj(pointsMtn1_2(), mountainMaterial);

    mtn1_2_obj.translateX(0);
    mtn1_2_obj.translateZ(15);

    mtn1_2_obj.scale.set(scale * 1.15, scale * 1.15, scale * 1.15);

    mtn1_group.add(mtn1_2_obj);


    // ============== Mountain 1 PT 3 ===============

    mtn1_3_obj = createMtnObj(pointsMtn1_3(), mountainTipMaterial);

    mtn1_3_obj.translateY(0.5);

    mtn1_3_obj.scale.set(1, 1, 1);

    mtn1_2_obj.add(mtn1_3_obj);



    // ================= Mountain 1 PT 4 ================

    mtn1_4_obj = createMtnObj(pointsMtn1_4(), mountainMaterial);

    mtn1_4_obj.translateX(-3);
    mtn1_4_obj.translateZ(-7);
    mtn1_4_obj.translateY(-0.2);

    mtn1_4_obj.rotateY(0.2);

    mtn1_group.add(mtn1_4_obj);


    // ================= Mountain 1 PT 5 ================

    mtn1_5_obj = createMtnObj(pointsMtn1_5(), mountainTipMaterial);

    mtn1_4_obj.add(mtn1_5_obj);

    mtn1_5_obj.scale.set(1, 1, 1);

    // Adding All Group of Mountains to the scene
    scene.add(mtn1_group);

  }

  function createMountain2() {


    // =============== Mountain 2 PT 0 ===============    

    mtn2_0_obj = createMtnObj(pointsMtn2_0(), mountainMaterial);

    mtn2_0_obj.translateY(-0.15);

    mtn2_0_obj.scale.set(scale * 1.4, scale * 1.4, scale * 1.4);

    mtn2_group.add(mtn2_0_obj);

    // =============== Mountain 2 PT 1 ===============  

    mtn2_1_obj = createMtnObj(pointsMtn2_1(), mountainTipMaterial);

    mtn2_0_obj.add(mtn2_1_obj);

    mtn2_1_obj.scale.set(1, 1, 1);

    // =============== Mountain 2 PT 2 ===============  

    mtn2_2_obj = createMtnObj(pointsMtn2_2(), mountainMaterial);

    mtn2_2_obj.translateX(9);

    mtn2_group.add(mtn2_2_obj);

    // =============== Mountain 2 PT 3 ===============  

    mtn2_3_obj = createMtnObj(pointsMtn2_3(), mountainTipMaterial);

    mtn2_2_obj.add(mtn2_3_obj);

    mtn2_3_obj.scale.set(1, 1, 1);


    // Adding All Group of Mountains to the scene
    scene.add(mtn2_group);

  }

  function createMtnObj(points, mat) {

    var localPoints = points;

    var mountainGeo = new THREE.ConvexBufferGeometry(localPoints);
    var mountainMat = mat;

    var mountainObj = null;

    mountainObj = new THREE.Mesh(mountainGeo, mountainMat);

    mountainObj.castShadow = true;
    mountainObj.receiveShadow = true;
    mountainObj.visible = true;

    mountainObj.scale.set(scale, scale, scale);

    return mountainObj;

  }

  // ============== END OF MOUNTAIN DEFINITIONS ===================



  // ============== EXTERNAL OBJECTS IMPORT FUNCTIONS ===================

  function loadOBJFile(modelPath, modelName, desiredScale) {

    var manager = new THREE.LoadingManager();

    var mtlLoader = new THREE.MTLLoader(manager);
    mtlLoader.setPath(modelPath);
    mtlLoader.load(modelName + '.mtl', function (materials) {

      materials.preload();

      var objLoader = new THREE.OBJLoader(manager);
      objLoader.setMaterials(materials);
      objLoader.setPath(modelPath);
      objLoader.load(modelName + ".obj", function (obj) {
        obj.visible = true;
        obj.name = modelName;
        obj.traverse(function (child) {
          child.castShadow = true;
          child.receiveShadow = true;
        });

        obj.traverse(function (node) {
          if (node.material) node.material.side = THREE.DoubleSide;
        });

        obj = normalizeAndRescale(obj, desiredScale);
        obj = fixPosition(obj);

        statue_group.add(obj);

      });
    });

  }

  function loadGLTFFile(modelPath, modelFolder, desiredScale, angle, visibility, group) {
    var loader = new THREE.GLTFLoader();
    loader.load(modelPath + modelFolder + '/scene.gltf', function (gltf) {
      var obj = gltf.scene;
      obj.visible = visibility;
      obj.name = modelFolder;
      obj.traverse(function (child) {
        if (child) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });
      obj.traverse(function (node) {
        if (node.material) node.material.side = THREE.DoubleSide;
      });

      var obj = normalizeAndRescale(obj, desiredScale);
      var obj = fixPosition(obj);
      obj.rotateY(degreesToRadians(angle));

      obj.castShadow = true;

      group.add(obj);

    });
  }

  // Normalize scale and multiply by the newScale
  function normalizeAndRescale(obj, newScale) {
    var scale = getMaxSize(obj); // Available in 'utils.js'
    obj.scale.set(newScale * (1.0 / scale),
      newScale * (1.0 / scale),
      newScale * (1.0 / scale));
    return obj;
  }

  // Ajust and fix position of the object
  function fixPosition(obj) {

    // Fix position of the object over the ground plane
    var box = new THREE.Box3().setFromObject(obj);
    if (box.min.y > 0) {
      obj.translateY(-box.min.y);
    }
    else {
      obj.translateY(-1 * box.min.y);
    }

    // Repositioning and Rotating
    obj.translateX(-75);
    obj.translateY(-85);
    obj.rotateX(1.53);

    return obj;
  }
  // ============== END OF EXTERNAL OBJECTS IMPORT FUNCTIONS ===================



  //-------------- ILUMINAÇÃO CONTROLE ------------------
  function buildInterface() {
    var controls = new function () {
      this.lightIntensity = lightIntensity;
      this.pointLightControl = true;
      this.spotLightControl = false;
      this.dirLightControl = true;

      this.onUpdateLightIntensity = function () {
        lightIntensity = this.lightIntensity;
        updateLightIntensity();
      };
      this.onDirLight = function () {
        dirLight.visible = this.dirLightControl;
        light.visible = this.dirLightControl;
      };
      this.onPointLight = function () {
        spotLight1.visible = this.pointLightControl;
        spotLight2.visible = this.pointLightControl;
        spotLight3.visible = this.pointLightControl;
        spotLight4.visible = this.pointLightControl;
        spotLight5.visible = this.pointLightControl;
        spotLight6.visible = this.pointLightControl;
        spotLight7.visible = this.pointLightControl;
        spotLight8.visible = this.pointLightControl;
      };
      this.onSpotLight = function () {
        spotLight.visible = this.spotLightControl;
      }
      updateLightIntensity();
    };

    var gui = new dat.GUI();

    gui.add(controls, 'pointLightControl', false)
      .name("Pole light")
      .onChange(function (e) { controls.onPointLight() });
    gui.add(controls, 'dirLightControl', false)
      .name(dirLight.name)
      .onChange(function (e) { controls.onDirLight() });
    gui.add(controls, 'spotLightControl', false)
      .name(spotLight.name)
      .onChange(function (e) { controls.onSpotLight() });
    gui.add(controls, 'lightIntensity', 0, 5)
      .name("Light Intensity")
      .onChange(function (e) { controls.onUpdateLightIntensity() });
  }

  // Listen window size changes
  window.addEventListener('resize', function () { onWindowResize(camera, renderer) }, false);


  // Handles Zoom in Gameplay Camera Mode
  window.addEventListener('wheel', onMouseWheel, true);

  function onMouseWheel(ev) {

    event.preventDefault();

    var maxZoomFactor = 12.0;

    if (zoomFactorY >= -maxZoomFactor && event.deltaY <= 0.0) {
      zoomFactorY += event.deltaY / 100;
      zoomFactorZ += event.deltaY / 800;
    }

    else if (zoomFactorY <= maxZoomFactor + 80 && event.deltaY >= 0.0) {
      zoomFactorY += event.deltaY / 100;
      zoomFactorZ += event.deltaY / 800;
    }

  }

  // call render
  buildInterface();
  render();

  function showInformation() {
    // Use this to show information onscreen
    controls = new InfoBox();
    controls.add("Trabalho 3: Kart Game");
    controls.addParagraph();
    controls.add("Use ArrowUp to accelerate and ArrowDown to break.");
    controls.add("Use ArrowLeft and ArrowRight to turn.");
    controls.add("Use Space to change camera mode.");
    controls.add("Use Mouse Wheel to zoom in and out in Gameplay Mode.");
    controls.add("In FreeCamera, use mouse to control the camera.");
    controls.show();
  }

  var message = new SecondaryBox("Camera mode: Gameplay");

  function render() {
    stats.update(); // Update FPS

    // if not in free camera mode, cant manipulate camera
    if (freeCameraMode) {
      trackballControls.update(); // camera controls with mouse
    }

    if (planeMode) {
      trackballControls.update(); // camera controls with mouse
    }

    keyboardUpdate(); // wait for keyboard map

    if (!cockPitMode) {
      updateCamera(); // keep the camera fixed in the object
    }

    animateWheels(); // turn animation

    handleKartSpeed(); // handle the speed of the kart

    requestAnimationFrame(render); // Show events
    renderer.render(scene, camera) // Render scene
  }
}
